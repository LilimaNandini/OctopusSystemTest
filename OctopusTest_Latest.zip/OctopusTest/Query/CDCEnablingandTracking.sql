
--------CAPTURE CDC FOR SALES PERSON	

--1. BEFORE ENABLE CDC WE NEED TO MAKE SURE THAT THE LOGGEDIN USER SHOULD BE DATABASE OWNER AND SERVER ADMIN OF THE PARTICULAR DATABASE
---- FOLLOWING QUERY MAKES SURE FOR THE SAME.

EXEC sp_changedbowner 'sa'

-- 2. ENABLE CDC ON DATABASE

IF EXISTS (

SELECT IS_CDC_ENABLED FROM SYS.DATABASES

WHERE NAME = 'ADVENTUREWORKS2017'

AND IS_CDC_ENABLED = 0

)
USE AdventureWorks2017
GO

--FOLLOWING QUERY USED TO ENABLE CDC DATABASE.

EXEC sys.sp_cdc_enable_db 

go

--FOLLOWING QUERY USED TO ENABLE CDC FOR THE GIVEN TABLE (IN OUR CASE PRODUCT)

exec sys.sp_cdc_enable_table

@source_schema = 'Production',

@source_name = 'Product',

@supports_net_changes = 1,

@role_name = null

go


--FOLLOWING QUERY USED TO ENABLE CDC FOR THE GIVEN TABLE (IN OUR CASE SALES PERSON)

exec sys.sp_cdc_enable_table

@source_schema = 'Sales',

@source_name = 'SalesPerson',

@supports_net_changes = 1,

@role_name = null

go


---FOLLOWING QUERY USED TO RETRIEVE ALL CHANGES FOR THE PRODUCT TABLE

declare @from_lsn binary(10)

set @from_lsn = sys.fn_cdc_get_min_lsn('Production_Product')
print @from_lsn

declare @to_lsn binary(10)

set @to_lsn = sys.fn_cdc_get_max_lsn()

declare @row_filter_option nvarchar(10)

set @row_filter_option = 'all'

-- then all corresponding changes ...

select * from cdc.fn_cdc_get_all_changes_Production_Product( @from_lsn, @to_lsn, 'all')


--FOLLOWING QUERY USED TO RETRIEVE ALL CHANGES RELATED TO SALES PERSON

go

declare @from_lsn binary(10)

set @from_lsn = sys.fn_cdc_get_min_lsn('sales_SalesPerson')
print @from_lsn

declare @to_lsn binary(10)

set @to_lsn = sys.fn_cdc_get_max_lsn()

declare @row_filter_option nvarchar(10)

set @row_filter_option = 'all'

-- then all corresponding changes ...

select * from cdc.fn_cdc_get_all_changes_Sales_SalesPerson( @from_lsn, @to_lsn, 'all') 

 